##' @method fitted FREEfit
##' @export
fitted.FREEfit <-
function(object, ...){
  object$fitted
}
