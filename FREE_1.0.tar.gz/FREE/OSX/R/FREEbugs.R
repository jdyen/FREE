FREEbugs <-
function(y, x, bins,family="gaussian", errors="ar1", n.basis=12, bugs.file=NULL, n.chains=3, n.iters=2000, n.burnin=n.iters/2, n.thin=1, debug=FALSE, bugs.dir=NULL, ...){
  stop("BUGS methods not supported in OSX version of FREE...", call.=FALSE)
}
