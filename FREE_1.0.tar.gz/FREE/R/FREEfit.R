FREEfit <-
function(y, ...){
  UseMethod("FREEfit")
}
