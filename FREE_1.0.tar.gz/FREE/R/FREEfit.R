FREEfit <-
function(x, ...){
  UseMethod("FREEfit")
}
