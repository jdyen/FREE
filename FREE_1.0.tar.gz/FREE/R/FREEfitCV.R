FREEfitCV <-
function(x, ...){
  UseMethod("FREEfitCV")
}
