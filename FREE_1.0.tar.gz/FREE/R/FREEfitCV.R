FREEfitCV <-
function(y, ...){
  UseMethod("FREEfitCV")
}
