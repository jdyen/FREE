fitted.FREEfit <-
function(object, ...){
  object$fitted
}
