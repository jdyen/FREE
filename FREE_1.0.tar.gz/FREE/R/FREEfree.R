FREEfree <-
function(y, x, bins, ...){
  stop("FREEfree has not been implemented yet...", call.=FALSE)
}
